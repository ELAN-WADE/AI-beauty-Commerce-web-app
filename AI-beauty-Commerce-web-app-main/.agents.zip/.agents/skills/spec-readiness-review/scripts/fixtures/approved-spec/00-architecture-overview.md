# Architecture

Fixture boundary.
