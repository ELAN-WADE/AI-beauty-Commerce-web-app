# File Structure

Fixture paths.
